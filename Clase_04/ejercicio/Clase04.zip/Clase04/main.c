#include <stdio.h>
#include <stdlib.h>
#include "funciones.h"

int main()
{
    int edad, legajo, nota;
    edad = pedirEntero("Ingrese edad: ", 18, 65);
    legajo = pedirEntero("Ingrese legajo: ", 0, 10000);
    nota = pedirEntero("Ingrese nota: ", 0, 10);
    //printf("El numero ingresado es %d\n", edad);
    return 0;
}
