/** \brief Devuelve un numero entero ingresado por el usuario.
 *
 * \param char[] Cadena de caracteres que corresponde con el mensaje a mostrar.
 * \param int Entero que representa el minimo del rango a validar.
 * \param int Entero que representa el maximo del rango a validar.
 * \return int El entero validado.
 *
 */
int pedirEntero(char[], int, int);
/** \brief
 *
 * \param int
 * \param int
 * \param int
 * \return int
 *
 */
int validarEntero(char[], int, int, int);
