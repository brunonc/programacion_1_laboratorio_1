#include "funciones.h"
#include <stdio.h>
#include <stdlib.h>

int pedirEntero(char msg[], int min, int max) {
    int res;
    printf("%s", msg);
    scanf("%d", &res);
    res = validarEntero(msg, res, min, max);
    return res;
}

int validarEntero(char msg[], int dato, int min, int max) {
    while (dato < min || dato > max) {
        printf("El dato ingresado es erroneo\n%s", msg);
        scanf("%d", &dato);
    }
    return dato;
}
