#include <stdio.h>
#include <stdlib.h>
#include "funciones.h"

int factorial(int);

int main()
{
    int n;
    long double res = 1;
    n = pedirEntero("Ingrese un entero para calcular el factorial: ", 0, 100);
    for (int i = 1; i <= n; i++) {
        res = res * i;
    }
    printf("El factorial de %d es %.0lf\n", n, res);
    printf("El factorial recursivo de %d es %.0lf", n, factorial(n));
    return 0;
}

int factorial(int numero) {
    if (numero == 0) {
        return 1;
    } else {
        return factorial(numero - 1);
    }
}
